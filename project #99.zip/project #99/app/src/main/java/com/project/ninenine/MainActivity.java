package com.project.ninenine;
 
import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends Activity { 
	EditText EditText1;
	EditText EditText2;
	Button btn;
	TextView tvResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		
        EditText1 = findViewById(R.id.EditText1);
		EditText2 = findViewById(R.id.EditText2);
		
		btn = findViewById(R.id.btn);
		
		tvResult = findViewById(R.id.tvResult);
		tvResult.setVisibility(View.GONE);
    }
	
	public void cal(View v ){
		
		String Text1 = EditText1.getText().toString();
		String Text2 = EditText2.getText().toString();
		
		if(Text1.isEmpty()||Text2.isEmpty()){
			return;
		}
		double aText1 = Double.parseDouble(Text1);
		double aText2= Double.parseDouble(Text2);
		
		tvResult.setVisibility(View.VISIBLE);
		tvResult.setText(aText1+aText2+"");	
		
	}
} 
