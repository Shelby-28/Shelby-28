package com.mycompany.application;
 
import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;
import android.app.AlertDialog;
import android.net.Uri;
import android.content.Intent;

public class MainActivity extends Activity { 
	//ImageButton cancelButton;
	Button cancelButton;
	Button ok_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
		View alertCustomDialog = LayoutInflater.from(MainActivity.this).inflate(R.drawable.custom_dialog,null);
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);

		alertDialog.setView(alertCustomDialog);
		cancelButton = (Button) alertCustomDialog.findViewById(R.id.cancelID);
		ok_btn = (Button) alertCustomDialog.findViewById(R.id.ok_btn_id);

		final  AlertDialog dialog = alertDialog.create();

		findViewById(R.id.showID).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					dialog.show();
				}
			});
		
		
			
		cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.cancel();
				}
			});
		ok_btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.cancel();
					Uri uri = Uri.parse("https://t.me/TheShelbyOne");
					Intent intent = new Intent(Intent.ACTION_VIEW, uri);
					startActivity(intent);
				}
			});
			
			
			
		
    }
	
} 

