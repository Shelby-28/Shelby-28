import hashlib
import time
flag=0
print('''
░█▀▀▀█ █──█ █▀▀ █── █▀▀▄ █──█ 
─▀▀▀▄▄ █▀▀█ █▀▀ █── █▀▀▄ █▄▄█ 
░█▄▄▄█ ▀──▀ ▀▀▀ ▀▀▀ ▀▀▀─ ▄▄▄█\n''')


print("Version: Beta")
print("Telegram: TheShelbyOne\n")

c = 1
t = 1
while c < 6:
    print("Score: 5")
    print("Tries: "+str(t)+"\n")
    pass_hash = input(str(t)+"-Enter md5 hash: ")
    word_list = input(str(t)+"-Enter File Name:")
    
    try:
        pass_file = open(word_list,"r")
    except:
        print("No File Found\n")
        if t >4:
            print("Tries: 5")
            print("NO MORE TRIES!\n")
        t+=1
        c += 1



for word in pass_file:
    
    enc_wrd = word.encode('utf-8')
    digest = hashlib.md5(enc_wrd.strip()).hexdigest()
    
    print("Tested Password: "+word)
    print("Tested Hash: "+digest)
    print("Real Hash: "+pass_hash)
    time.sleep(0.1)
        
    if digest == pass_hash:
        print("𝗣𝗮𝘀𝘀𝘄𝗼𝗿𝗱 𝗳𝗼𝘂𝗻𝗱 !\n")
        print("Password is: " + word)
        flag=1
        break;
if flag == 0:
    print("Password is not in the list")
    
    
    
    



