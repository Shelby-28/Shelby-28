package com.convert.temp;

import android.app.Activity;
import android.icu.text.DecimalFormat;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity { 
    EditText etTemp;
    Button btnConvert;
    TextView tvResult;
    DecimalFormat Formater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        
        etTemp = findViewById(R.id.etTemp);
        btnConvert = findViewById(R.id.btnConvert);
        tvResult = findViewById(R.id.tvResult);
        
        tvResult.setVisibility(View.GONE);
        Formater = new DecimalFormat("#0.00");

    }

    public void Convert(View v) {


        String temp = etTemp.getText().toString().trim();
        
        if (temp.isEmpty()) {
            return;
        }
        double result2 = Double.parseDouble(temp);
        double a = (result2 *= 9) / 5 + 32; 
        tvResult.setVisibility(View.VISIBLE);
        tvResult.setText(Formater.format(a) + "°F");
    }
    public void convert2(View v) {

        String temp2 = etTemp.getText().toString().trim();
        if (temp2.isEmpty()) {
            return;
        }
        double result3 = Double.parseDouble(temp2);
        double a2  = (result3 -= 32) * 5 / 9;
        tvResult.setVisibility(View.VISIBLE);
        tvResult.setText(Formater.format(a2) + "°C");
    }

} 
