import telebot
from Key import API_KEY
bot = telebot.TeleBot(API_KEY,parse_mode=None)

@bot.message_handler(commands=["help","hi"])
def send_help_massage(msg):
    bot.reply_to(msg,"Wlcome\nBot Version : Alpha \nAll Commands:/X -Getes You all Command")
    
    
    
@bot.message_handler(commands=["start"])
def send_start_massage(msg):
    bot.reply_to(msg,"Welcome")
 

@bot.message_handler(commands=["X"])
def send_X_massage(msg):
	
    is_bot =msg.from_user.is_bot
    first_name = msg.from_user.first_name
    last_name=msg.from_user.last_name
    username=msg.from_user.username
    invite_link=msg.chat.invite_link
    bio=msg.chat.bio
    language_code=msg.from_user.language_code
    is_premium=msg.from_user.is_premium
    description=msg.chat.description
    permissions=msg.chat.permissions
    
    X = "Is Bot: "+str(is_bot)+"\nFirst Name: " + str(first_name) + "\nLast Name: "+ str(last_name)+"\nUsername: "+str(username)+"\nInvite Link: "+str(invite_link) +"\nBio: "+str(bio)+"\nPremium: "+str(is_premium)+"\nPermissions: "+str(permissions)+"\nDescription: "+str(description)+"\nLanguage: "+str(language_code)
  
    bot.reply_to(msg,X)
    
    
    
    
    
    
    
    
    
#@bot.message_handler(filters)
#def function_name(message):
	#bot.reply_to(message, "This is a message handler")
      
#Sendes Your Own message        
#@bot.message_handler(func=lambda message: True)
#def echo_all(message):
	#bot.reply_to(message, message.text)
 
 
print("Working...")    
bot.polling()
    
