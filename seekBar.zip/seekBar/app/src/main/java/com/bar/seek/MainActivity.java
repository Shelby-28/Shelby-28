package com.bar.seek;
 
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.SeekBar;
import android.graphics.Color;

public class MainActivity extends Activity { 
     TextView Tv;
     SeekBar seekBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        seekBar = findViewById(R.id.SeekBarId);
        Tv = findViewById(R.id.TvId);
        
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean b) {
                    if(progress ==1){
                       // Tv.setTextColor(Color.argb(255, 255, 0,0));
                        Tv.setTextColor(Color.parseColor("#ff0000"));
                    }
                        Tv.setText("Now is: "+ String.valueOf(progress));
                    
                    
                }

                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {

                }

                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {

                }
            });
    }
}
