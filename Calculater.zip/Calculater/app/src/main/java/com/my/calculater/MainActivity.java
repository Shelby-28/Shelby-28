package com.my.calculater;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import org.xml.sax.Parser;
import android.widget.Switch;
import android.view.LayoutInflater;
import android.widget.LinearLayout;

public class MainActivity extends Activity { 
    EditText value1_et;
    EditText value2_et;
    TextView tvResult_tv;
    Button btn_btn;

    Button btn2;//-
    Button btn3;//*
    Button btn4;//÷
    Switch Sw;

    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //hooks

        value1_et = findViewById(R.id.value1);
        value2_et = findViewById(R.id.value2);
        tvResult_tv = findViewById(R.id.tvResult);

        btn2 = findViewById(R.id.btn2);//-
        btn3 = findViewById(R.id.btn3);//*
        btn4 = findViewById(R.id.btn4);//÷
        Sw = findViewById(R.id.Sw);
    }
    
    public void change(View v) {
        tvResult_tv.setVisibility(View.VISIBLE);
        String str1 = value1_et.getText().toString();
        String str2 = value2_et.getText().toString();

        if (str1.isEmpty() || str2.isEmpty()) {
            tvResult_tv.setVisibility(View.GONE);
            return;
        } 
        Float f1 = Float.parseFloat(str1);
        Float f2 = Float.parseFloat(str2);
        Float reslut = f1 + f2;
        tvResult_tv.setText(reslut + "");
    }
    
    public void change2(View v) {
        tvResult_tv.setVisibility(View.VISIBLE);
        String str1 = value1_et.getText().toString();
        String str2 = value2_et.getText().toString();

        if (str1.isEmpty() || str2.isEmpty()) {
            tvResult_tv.setVisibility(View.GONE);
            return;
        }
        float f1 = Float.parseFloat(str1);
        float f2 = Float.parseFloat(str2); 
        float result = f1 - f2;
        tvResult_tv.setText(result + "");
    }

    public void change3(View v) {
        tvResult_tv.setVisibility(View.VISIBLE);
        // TODO: Remaber This its IMPORTNT
        String str1 = value1_et.getText().toString();
        String str2 = value2_et.getText().toString();

        if (str1.isEmpty() || str2.isEmpty()) {
            tvResult_tv.setVisibility(View.GONE);
            return;
        }
        float f1 = Float.parseFloat(str1);
        float f2 = Float.parseFloat(str2);
        float result = f1 * f2;
        tvResult_tv.setText(result + "");
        
    }
    public void change4(View v) {
        tvResult_tv.setVisibility(View.VISIBLE);
        String str1 = value1_et.getText().toString();
        String str2 = value2_et.getText().toString();

        if (str1.isEmpty() || str2.isEmpty()) {
            tvResult_tv.setVisibility(View.GONE);
            return;
        }
        float f1 = Float.parseFloat(str1);
        float f2 = Float.parseFloat(str2);
        float result = f1 / f2;
        tvResult_tv.setText(result + "");
    }
    
    public void Switch(View v){
       if(Sw.isChecked()){
           Sw.setText("ON");
           
       }else{
           Sw.setText("OFF");
       }
    }
} 
