package com.convert.temp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.icu.text.DecimalFormat;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends Activity { 
    EditText etTemp;
    Button btnConvert;
    TextView tvResult;
	Button cancelButton;
	Button ok_btn;
    DecimalFormat Formater;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        etTemp = findViewById(R.id.etTemp);
        btnConvert = findViewById(R.id.btnConvert);
        tvResult = findViewById(R.id.tvResult);

        tvResult.setVisibility(View.GONE);
        Formater = new DecimalFormat("#0.00");


		View alertCustomDialog = LayoutInflater.from(MainActivity.this).inflate(R.drawable.custom_dialog, null);
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(MainActivity.this);

		alertDialog.setView(alertCustomDialog);
		cancelButton = (Button) alertCustomDialog.findViewById(R.id.cancelID);
		ok_btn = (Button) alertCustomDialog.findViewById(R.id.ok_btn_id);

		final  AlertDialog dialog = alertDialog.create();

		findViewById(R.id.showID).setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
					dialog.show();
				}
			});


		cancelButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.cancel();
				}
			});
		ok_btn.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					dialog.cancel();
					Uri uri = Uri.parse("https://t.me/TheShelbyOne");
					Intent intent = new Intent(Intent.ACTION_VIEW, uri);
					startActivity(intent);
				}
			});


	}



    public void Convert(View v) {


        String temp = etTemp.getText().toString().trim();

        if (temp.isEmpty()) {
            return;
        }
        float result2 = Float.parseFloat(temp);
        float a = (result2 *= 9) / 5 + 32; 
        tvResult.setVisibility(View.VISIBLE);
        tvResult.setText(Formater.format(a) + "°F");
    }


    public void convert2(View v) {

        String temp2 = etTemp.getText().toString().trim();
        if (temp2.isEmpty()) {
            return;
        }
        float result3 = Float.parseFloat(temp2);
        float a2  = (result3 -= 32) * 5 / 9;
        tvResult.setVisibility(View.VISIBLE);
        tvResult.setText(Formater.format(a2) + "°C");
    }
    public void convert3(View v) {
        String temp2 = etTemp.getText().toString().trim();
        if (temp2.isEmpty()) {
            return;
        }
        float result3 = Float.parseFloat(temp2);
        float a2  = (result3 += 273.15);
        tvResult.setVisibility(View.VISIBLE);
        tvResult.setText(Formater.format(a2) + "°K");
    }


}
